# Azad Coin Android Build

Package ID: `com.azadcoin.app`
App name: `Azad Coin`

## GitHub Actions (recommended)
1. Upload the entire project to a GitHub repository.
2. Open **Actions** > **Build Azad Coin Android APK** > **Run workflow**.
3. When the job finishes, open the run and download **Azad-Coin-APK** from Artifacts.
4. The installable file is `app-release.apk`.
5. **Azad-Coin-AAB** is also produced for Google Play.

The workflow installs stable Flutter, generates the missing Android platform, sets the package ID, adds Internet permission, runs dependency resolution and analysis, and builds release APK/AAB.

## Local build
With Flutter + Android SDK installed:

```bash
flutter create --platforms=android --org com.azadcoin --project-name azad_coin_app .
flutter pub get
flutter analyze
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`
