# Azad Coin — Flutter App

Official Azad Coin mobile app (Android + iOS). Obsidian black + gold design, Pashto/Dari/English with RTL support, connected to the existing Azad Coin backend (Lovable Cloud / Supabase).

## Setup

1. Install Flutter SDK 3.x: https://docs.flutter.dev/get-started/install
2. In this folder run:
   ```bash
   flutter pub get
   flutter run            # test on a device/emulator
   flutter build apk --release        # Android APK
   flutter build appbundle --release  # Google Play AAB
   flutter build ipa                  # iOS (on macOS)
   ```

## Backend

Already configured in `lib/main.dart` (Supabase URL + anon key). Uses your existing tables:
`wallets`, `profiles`, `token_settings`, `islamic_staking_positions`, `transactions`.

## Included screens

- Splash with maintenance-mode check
- Login and OTP-verified signup
- Dashboard: total balance, live server price and Realtime wallet refresh
- AZAD/USDT/AFN wallet, BEP20 deposit address and internal transfer
- Server-authoritative AZAD/USDT swap via `execute_swap`
- Islamic Staking positions and transaction history
- KYC, referral, mining, lottery, card, gifts, support and notifications hub
- Profile, biometric/security entry point and logout

## Security rules

- The app never directly changes `wallets` balances.
- Prices, fees and financial results come from server RPC/Edge Functions.
- Only the public anon key is included; never add a service-role key.
- RLS and server account restrictions remain authoritative.

## Before production release

- Confirm deployed RPC parameter names match `lib/services/supabase_service.dart`.
- Add the final logo/app icon and configure a private Android signing key.
- Test OTP, deposit, send, swap, staking and KYC on a staging user first.
