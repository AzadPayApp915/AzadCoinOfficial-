import 'package:flutter/material.dart';

class AppStrings {
  static String of(BuildContext context, String key) {
    final code = Localizations.localeOf(context).languageCode;
    return _values[code]?[key] ?? _values['en']![key] ?? key;
  }

  static const _values = {
    'en': {
      'dashboard': 'Dashboard', 'wallet': 'Wallet', 'support': 'Support',
      'profile': 'Profile', 'totalBalance': 'TOTAL BALANCE',
      'price': 'AZAD PRICE', 'live': 'Live', 'convert': 'Convert',
      'send': 'Send AZAD', 'deposit': 'Deposit', 'staking': 'Staking',
      'withdraw': 'Withdraw', 'gift': 'Gift', 'pockets': 'Read Pockets',
      'lottery': 'Lottery', 'mining': 'Mining', 'referral': 'Referral',
      'ambassador': 'Ambassador', 'leaderboard': 'Leaderboard',
      'afnWallet': 'AFN Wallet', 'whitepaper': 'Whitepaper',
      'withdrawalStats': 'Withdrawal Stats', 'transactions': 'Transactions',
      'comingSoon': 'will be available soon.', 'allTransactions': 'View all transactions',
      'language': 'Language', 'theme': 'Theme',
    },
    'ps': {
      'dashboard': 'ډشبورډ', 'wallet': 'والټ', 'support': 'مرسته',
      'profile': 'پروفایل', 'totalBalance': 'ټوله شتمني',
      'price': 'د AZAD بیه', 'live': 'ژوندی', 'convert': 'بدلول',
      'send': 'AZAD ولېږه', 'deposit': 'ډیپازېټ', 'staking': 'سټېکینګ',
      'withdraw': 'ایستل', 'gift': 'ډالۍ', 'pockets': 'Read Pockets',
      'lottery': 'قرعه', 'mining': 'مایننګ', 'referral': 'ریفرل',
      'ambassador': 'استازی', 'leaderboard': 'مشران',
      'afnWallet': 'افغانی والټ', 'whitepaper': 'سپین کتاب',
      'withdrawalStats': 'د ایستلو احصایه', 'transactions': 'لېږدونه',
      'comingSoon': 'ژر به فعاله شي.', 'allTransactions': 'ټول لېږدونه وګوره',
      'language': 'ژبه', 'theme': 'رنګ',
    },
    'fa': {
      'dashboard': 'داشبورد', 'wallet': 'کیف پول', 'support': 'پشتیبانی',
      'profile': 'پروفایل', 'totalBalance': 'موجودی کل',
      'price': 'قیمت AZAD', 'live': 'زنده', 'convert': 'تبدیل',
      'send': 'ارسال AZAD', 'deposit': 'واریز', 'staking': 'استیکینگ',
      'withdraw': 'برداشت', 'gift': 'هدیه', 'pockets': 'پاکت‌ها',
      'lottery': 'قرعه‌کشی', 'mining': 'ماینینگ', 'referral': 'معرفی',
      'ambassador': 'سفیر', 'leaderboard': 'رتبه‌بندی',
      'afnWallet': 'کیف افغانی', 'whitepaper': 'وایت‌پیپر',
      'withdrawalStats': 'آمار برداشت', 'transactions': 'تراکنش‌ها',
      'comingSoon': 'به‌زودی فعال می‌شود.', 'allTransactions': 'همه تراکنش‌ها',
      'language': 'زبان', 'theme': 'رنگ',
    },
  };
}
