import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'theme/app_theme.dart';
import 'screens/splash_screen.dart';

/// Azad Coin backend (Lovable Cloud / Supabase)
const supabaseUrl = 'https://khthsmgeechcoqibnwby.supabase.co';
const supabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtodGhzbWdlZWNoY29xaWJud2J5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcxNzIxMTksImV4cCI6MjA4Mjc0ODExOX0.Ut2RONJxLNhdNwO8MosGGPayPiMDcRLnJVIm2-65Mow';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const AzadCoinApp());
}

class AzadCoinApp extends StatefulWidget {
  const AzadCoinApp({super.key});

  static _AzadCoinAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_AzadCoinAppState>()!;

  @override
  State<AzadCoinApp> createState() => _AzadCoinAppState();
}

class _AzadCoinAppState extends State<AzadCoinApp> {
  ThemeMode themeMode = ThemeMode.light;
  Locale locale = const Locale('en');

  void toggleTheme() => setState(() {
        themeMode = themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
      });
  void setLocale(Locale value) => setState(() => locale = value);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Azad Coin',
      debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,
      locale: locale,
      supportedLocales: const [Locale('en'), Locale('ps'), Locale('fa')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const SplashScreen(),
    );
  }
}
