import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import '../services/supabase_service.dart';
import '../widgets/glass_card.dart';
import 'home_shell.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  bool isLogin = true;
  String? error;
  final LocalAuthentication biometric = LocalAuthentication();

  Future<void> _biometricLogin() async {
    setState(() { loading = true; error = null; });
    try {
      if (!SupabaseService.isLoggedIn) {
        throw Exception('First login with your email and password, then biometric unlock will be available.');
      }
      final available = await biometric.canCheckBiometrics || await biometric.isDeviceSupported();
      if (!available) throw Exception('Fingerprint or Face ID is not available on this device.');
      final allowed = await biometric.authenticate(
        localizedReason: 'Verify your identity to open Azad Coin',
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      if (!mounted || !allowed) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeShell()));
    } catch (e) {
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<String?> _askForOtp() async {
    final otp = TextEditingController();
    return showDialog<String>(context: context, barrierDismissible: false, builder: (dialogContext) => AlertDialog(
      title: const Text('Verify email'),
      content: TextField(controller: otp, keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'OTP code')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(dialogContext, otp.text.trim()), child: const Text('Verify')),
      ],
    ));
  }

  Future<void> _submit() async {
    setState(() { loading = true; error = null; });
    try {
      if (isLogin) {
        await SupabaseService.signIn(email.text.trim(), password.text);
      } else {
        await SupabaseService.sendSignupOtp(email.text.trim());
        if (!mounted) return;
        final otp = await _askForOtp();
        if (otp == null || otp.isEmpty) return;
        await SupabaseService.verifySignupOtp(email.text.trim(), otp);
        await SupabaseService.signUp(email.text.trim(), password.text);
      }
      if (!mounted) return;
      if (SupabaseService.isLoggedIn) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeShell()));
      } else {
        setState(() => error = 'Check your email for verification.');
      }
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasSession = SupabaseService.isLoggedIn;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Center(child: ClipOval(child: Image.asset('assets/azad_coin_logo.png', width: 84, height: 84, fit: BoxFit.cover))),
                const SizedBox(height: 14),
                const Text('AZAD COIN', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFFE6A302), letterSpacing: 3, fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 18),
                Text(hasSession ? 'Welcome back' : (isLogin ? 'ننوتل / Login' : 'حساب جوړول / Sign Up'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 20),
                if (!hasSession) ...[
                  TextField(controller: email, keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(hintText: 'Email')),
                  const SizedBox(height: 12),
                  TextField(controller: password, obscureText: true,
                      decoration: const InputDecoration(hintText: 'Password')),
                ] else const Text('Use your fingerprint or Face ID to securely open your wallet.', textAlign: TextAlign.center),
                if (error != null) ...[
                  const SizedBox(height: 12),
                  Text(error!, style: const TextStyle(color: Colors.redAccent, fontSize: 13)),
                ],
                const SizedBox(height: 20),
                if (!hasSession) ElevatedButton(
                    onPressed: loading ? null : _submit,
                    child: loading
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(isLogin ? 'Login' : 'Create Account'),
                  ),
                if (!hasSession) const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: loading ? null : _biometricLogin,
                  icon: const Icon(Icons.fingerprint_rounded, size: 27),
                  label: const Text('Biometric Login'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFE2A100),
                    side: const BorderSide(color: Color(0xFFE2A100)),
                    minimumSize: const Size.fromHeight(52),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
                if (!hasSession) TextButton(
                    onPressed: () => setState(() => isLogin = !isLogin),
                    child: Text(isLogin ? 'Create account' : 'Have an account? Login'),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
