import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import '../widgets/glass_card.dart';
import 'home_shell.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  bool isLogin = true;
  String? error;

  Future<String?> _askForOtp() async {
    final otp = TextEditingController();
    return showDialog<String>(context: context, barrierDismissible: false, builder: (dialogContext) => AlertDialog(
      title: const Text('Verify email'),
      content: TextField(controller: otp, keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'OTP code')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(dialogContext, otp.text.trim()), child: const Text('Verify')),
      ],
    ));
  }

  Future<void> _submit() async {
    setState(() { loading = true; error = null; });
    try {
      if (isLogin) {
        await SupabaseService.signIn(email.text.trim(), password.text);
      } else {
        await SupabaseService.sendSignupOtp(email.text.trim());
        if (!mounted) return;
        final otp = await _askForOtp();
        if (otp == null || otp.isEmpty) return;
        await SupabaseService.verifySignupOtp(email.text.trim(), otp);
        await SupabaseService.signUp(email.text.trim(), password.text);
      }
      if (!mounted) return;
      if (SupabaseService.isLoggedIn) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeShell()));
      } else {
        setState(() => error = 'Check your email for verification.');
      }
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(isLogin ? 'ننوتل / Login' : 'حساب جوړول / Sign Up',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 20),
                TextField(controller: email, keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(hintText: 'Email')),
                const SizedBox(height: 12),
                TextField(controller: password, obscureText: true,
                    decoration: const InputDecoration(hintText: 'Password')),
                if (error != null) ...[
                  const SizedBox(height: 12),
                  Text(error!, style: const TextStyle(color: Colors.redAccent, fontSize: 13)),
                ],
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: loading ? null : _submit,
                  child: loading
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(isLogin ? 'Login' : 'Create Account'),
                ),
                TextButton(
                  onPressed: () => setState(() => isLogin = !isLogin),
                  child: Text(isLogin ? 'Create account' : 'Have an account? Login'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
