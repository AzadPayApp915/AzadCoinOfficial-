import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';
import 'staking_screen.dart';
import 'transactions_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? wallet;
  double azadPrice = 0;
  bool loading = true;
  dynamic walletChannel;

  @override
  void initState() {
    super.initState();
    _load();
    walletChannel = SupabaseService.subscribeToWallet(_load);
  }

  @override
  void dispose() {
    if (walletChannel != null) SupabaseService.client.removeChannel(walletChannel);
    super.dispose();
  }

  Future<void> _load() async {
    final w = await SupabaseService.getWallet();
    final p = await SupabaseService.getAzadPrice();
    if (mounted) setState(() { wallet = w; azadPrice = p; loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    final usd = NumberFormat.currency(symbol: '\$', decimalDigits: 2);
    final azad = (wallet?['azad_balance'] as num?)?.toDouble() ?? 0;
    final usdt = (wallet?['usdt_balance'] as num?)?.toDouble() ?? 0;
    final total = usdt + azad * azadPrice;

    return Scaffold(
      appBar: AppBar(title: const Text('Azad Coin')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          // Gold total-balance card
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [Color(0xFF2A2400), Color(0xFF171A22)]),
              border: Border.all(color: AppColors.gold.withOpacity(0.35)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Total Balance', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
              const SizedBox(height: 8),
              Text(loading ? '—' : usd.format(total),
                  style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: AppColors.gold)),
              const SizedBox(height: 16),
              Row(children: [
                _pill('AZAD', NumberFormat('#,##0.######').format(azad)),
                const SizedBox(width: 10),
                _pill('USDT', usd.format(usdt)),
              ]),
            ]),
          ),
          const SizedBox(height: 14),
          GlassCard(child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('AZAD Price', style: TextStyle(fontWeight: FontWeight.w700)),
            Row(children: [
              Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle)),
              const SizedBox(width: 8),
              Text('\$${azadPrice.toStringAsFixed(6)}',
                  style: const TextStyle(color: AppColors.green, fontWeight: FontWeight.w800)),
            ]),
          ])),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: _quick(Icons.savings_rounded, 'Islamic Staking',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StakingScreen())))),
            const SizedBox(width: 10),
            Expanded(child: _quick(Icons.receipt_long_rounded, 'Transactions',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionsScreen())))),
          ]),
        ]),
      ),
    );
  }

  Widget _pill(String label, String value) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.06),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Text('$label  $value', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
  );

  Widget _quick(IconData icon, String label, VoidCallback tap) => InkWell(
    onTap: tap, borderRadius: BorderRadius.circular(20),
    child: GlassCard(padding: const EdgeInsets.all(16), child: Column(children: [
      Icon(icon, color: AppColors.gold), const SizedBox(height: 8),
      Text(label, textAlign: TextAlign.center,
        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
    ])),
  );
}
