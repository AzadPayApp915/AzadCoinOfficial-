import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/supabase_service.dart';
import 'staking_screen.dart';
import 'transactions_screen.dart';
import 'swap_screen.dart';
import 'wallet_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? wallet;
  double azadPrice = 0;
  bool loading = true;
  dynamic walletChannel;

  @override
  void initState() { super.initState(); _load(); walletChannel = SupabaseService.subscribeToWallet(_load); }
  @override
  void dispose() { if (walletChannel != null) SupabaseService.client.removeChannel(walletChannel); super.dispose(); }

  Future<void> _load() async {
    try {
      final w = await SupabaseService.getWallet();
      final p = await SupabaseService.getAzadPrice();
      if (mounted) setState(() { wallet = w; azadPrice = p; loading = false; });
    } catch (_) { if (mounted) setState(() => loading = false); }
  }

  void _open(Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  void _soon(String feature) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$feature به ژر فعاله شي.')));

  @override
  Widget build(BuildContext context) {
    final azad = (wallet?['azad_balance'] as num?)?.toDouble() ?? 0;
    final usdt = (wallet?['usdt_balance'] as num?)?.toDouble() ?? 0;
    final total = usdt + azad * azadPrice;
    final money = NumberFormat.currency(symbol: '\$', decimalDigits: 2);
    return Scaffold(
      backgroundColor: const Color(0xFFFFFCF5),
      body: SafeArea(child: RefreshIndicator(
        color: const Color(0xFFE6A302), onRefresh: _load,
        child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.fromLTRB(20, 16, 20, 24), children: [
          _header(), const SizedBox(height: 20), _goldCard(total, usdt, azad, money), const SizedBox(height: 16), _price(), const SizedBox(height: 22),
          GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .9, children: [
            _action(Icons.sensors_rounded, 'Live', () => _soon('Live')),
            _action(Icons.swap_vert_rounded, 'Convert', () => _open(const SwapScreen())),
            _action(Icons.send_rounded, 'Send AZAD', () => _open(const WalletScreen())),
            _action(Icons.south_west_rounded, 'Deposit', () => _open(const WalletScreen())),
            _action(Icons.diamond_outlined, 'Staking', () => _open(const StakingScreen())),
            _action(Icons.north_east_rounded, 'Withdraw', () => _open(const WalletScreen())),
          ]),
          const SizedBox(height: 8), TextButton.icon(onPressed: () => _open(const TransactionsScreen()), icon: const Icon(Icons.receipt_long_rounded), label: const Text('ټول Transactions وګوره'), style: TextButton.styleFrom(foregroundColor: const Color(0xFF9B6500))),
        ]),
      )),
    );
  }

  Widget _header() => Row(children: [
    Container(width: 45, height: 45, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFFFD86D), Color(0xFF9B6100)])), child: const Icon(Icons.currency_bitcoin_rounded, color: Color(0xFF523100))),
    const SizedBox(width: 10), const Text('AZAD', style: TextStyle(color: Color(0xFFE4A105), fontSize: 25, fontWeight: FontWeight.w900)), const Spacer(),
    _icon(Icons.light_mode_outlined), const SizedBox(width: 7), _icon(Icons.language_rounded), const SizedBox(width: 7), _icon(Icons.notifications_none_rounded),
  ]);

  Widget _icon(IconData icon) => Container(width: 42, height: 42, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: const Color(0xFF292929)));

  Widget _goldCard(double total, double usdt, double azad, NumberFormat money) => Container(
    height: 365, padding: const EdgeInsets.all(23), decoration: BoxDecoration(borderRadius: BorderRadius.circular(32), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF281600), Color(0xFF765017), Color(0xFF170C03)]), border: Border.all(color: const Color(0xFFDBAF4B)), boxShadow: const [BoxShadow(color: Color(0x332A1700), blurRadius: 22, offset: Offset(0, 10))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Container(width: 52, height: 52, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFBD7918)), child: const Icon(Icons.currency_bitcoin_rounded, color: Color(0xFFFFE7A2), size: 31)), const SizedBox(width: 12), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('A Z A D', style: TextStyle(color: Color(0xFFFFD978), fontSize: 20, letterSpacing: 4, fontWeight: FontWeight.w900)), Text('GOLD PREMIUM', style: TextStyle(color: Color(0xFFF0D094), fontSize: 11, letterSpacing: 3, fontWeight: FontWeight.w700))]), const Spacer(), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF276D4C), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF66C695))), child: const Text('ACTIVE', style: TextStyle(color: Color(0xFFABF3C9), fontWeight: FontWeight.w800))) ]),
      const Spacer(), const Text('TOTAL BALANCE', style: TextStyle(color: Color(0xFFE2BF7E), fontSize: 12, letterSpacing: 3)), const SizedBox(height: 3), Text(loading ? '—' : money.format(total), style: const TextStyle(color: Color(0xFFFFDA7A), fontSize: 34, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text('${money.format(usdt)} USDT  •  ${NumberFormat('#,##0.######').format(azad)} AZAD', style: const TextStyle(color: Color(0xFFF1D39A), fontWeight: FontWeight.w600)),
      const Spacer(), Row(children: [Container(width: 58, height: 44, decoration: BoxDecoration(color: const Color(0xFFD9AD3E), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.memory_rounded, color: Color(0xFF875707), size: 31)), const SizedBox(width: 15), const Text('••••  ••••  ••••  4567', style: TextStyle(color: Color(0xFFFFE1A4), letterSpacing: 2, fontSize: 15, fontWeight: FontWeight.w800))]), const SizedBox(height: 18),
      const Row(children: [Expanded(child: _Label('CARD HOLDER', 'AZAD MEMBER')), _Label('EXPIRES', '07/36'), SizedBox(width: 24), _Label('CVC', '•••')]),
    ]),
  );

  Widget _price() => Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 17), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFF0DFB2))), child: Row(children: [Container(width: 10, height: 10, decoration: const BoxDecoration(color: Color(0xFF35D6A6), shape: BoxShape.circle)), const SizedBox(width: 12), const Text('AZAD PRICE', style: TextStyle(color: Color(0xFF857B69), fontWeight: FontWeight.w800, letterSpacing: 1.4)), const Spacer(), Text('\$${azadPrice.toStringAsFixed(6)}', style: const TextStyle(color: Color(0xFF9B6500), fontSize: 17, fontWeight: FontWeight.w900))]));

  Widget _action(IconData icon, String label, VoidCallback tap) => Material(color: Colors.white, borderRadius: BorderRadius.circular(24), child: InkWell(onTap: tap, borderRadius: BorderRadius.circular(24), child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFF0DFB2))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Container(width: 58, height: 58, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFFFFF7E5), border: Border.all(color: const Color(0xFFF2D487))), child: Icon(icon, color: const Color(0xFFE9A300), size: 30)), const SizedBox(height: 12), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: Color(0xFF262626), fontWeight: FontWeight.w800))]))));
}

class _Label extends StatelessWidget {
  final String label, value;
  const _Label(this.label, this.value);
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Color(0xFFE1BE7C), fontSize: 9, letterSpacing: 1.4)), const SizedBox(height: 4), Text(value, style: const TextStyle(color: Color(0xFFFFE1A4), fontSize: 13, fontWeight: FontWeight.w800))]);
}
