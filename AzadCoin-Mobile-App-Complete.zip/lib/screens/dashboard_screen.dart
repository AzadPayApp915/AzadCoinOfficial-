import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/supabase_service.dart';
import 'staking_screen.dart';
import 'transactions_screen.dart';
import 'swap_screen.dart';
import 'wallet_screen.dart';
import '../app_strings.dart';
import '../main.dart';
import '../theme/app_theme.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? wallet;
  double azadPrice = 0;
  bool loading = true;
  dynamic walletChannel;

  @override
  void initState() { super.initState(); _load(); walletChannel = SupabaseService.subscribeToWallet(_load); }
  @override
  void dispose() { if (walletChannel != null) SupabaseService.client.removeChannel(walletChannel); super.dispose(); }

  Future<void> _load() async {
    try {
      final w = await SupabaseService.getWallet();
      final p = await SupabaseService.getAzadPrice();
      if (mounted) setState(() { wallet = w; azadPrice = p; loading = false; });
    } catch (_) { if (mounted) setState(() => loading = false); }
  }

  void _open(Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  void _soon(String feature) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('$feature ${AppStrings.of(context, 'comingSoon')}')),
  );

  @override
  Widget build(BuildContext context) {
    final azad = (wallet?['azad_balance'] as num?)?.toDouble() ?? 0;
    final usdt = (wallet?['usdt_balance'] as num?)?.toDouble() ?? 0;
    final total = usdt + azad * azadPrice;
    final money = NumberFormat.currency(symbol: '\$', decimalDigits: 2);
    String t(String key) => AppStrings.of(context, key);
    return Scaffold(
      backgroundColor: Theme.of(context).brightness == Brightness.dark ? AppColors.bg : const Color(0xFFFFFCF5),
      body: SafeArea(child: RefreshIndicator(
        color: const Color(0xFFE6A302), onRefresh: _load,
        child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.fromLTRB(20, 16, 20, 24), children: [
          _header(), const SizedBox(height: 20), _goldCard(total, usdt, azad, money), const SizedBox(height: 16), _price(), const SizedBox(height: 22),
          GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .9, children: [
            _action(Icons.sensors_rounded, t('live'), () => _soon(t('live'))),
            _action(Icons.swap_vert_rounded, t('convert'), () => _open(const SwapScreen())),
            _action(Icons.send_rounded, t('send'), () => _open(const WalletScreen())),
            _action(Icons.south_west_rounded, t('deposit'), () => _open(const WalletScreen())),
            _action(Icons.diamond_outlined, t('staking'), () => _open(const StakingScreen())),
            _action(Icons.north_east_rounded, t('withdraw'), () => _open(const WalletScreen())),
            _action(Icons.card_giftcard_rounded, t('gift'), () => _soon(t('gift'))),
            _action(Icons.menu_book_rounded, t('pockets'), () => _soon(t('pockets'))),
            _action(Icons.confirmation_num_outlined, t('lottery'), () => _soon(t('lottery'))),
            _action(Icons.construction_rounded, t('mining'), () => _soon(t('mining'))),
            _action(Icons.groups_rounded, t('referral'), () => _soon(t('referral'))),
            _action(Icons.workspace_premium_rounded, t('ambassador'), () => _soon(t('ambassador'))),
            _action(Icons.emoji_events_outlined, t('leaderboard'), () => _soon(t('leaderboard'))),
            _action(Icons.account_balance_wallet_outlined, t('afnWallet'), () => _open(const WalletScreen())),
            _action(Icons.description_outlined, t('whitepaper'), () => _soon(t('whitepaper'))),
            _action(Icons.bar_chart_rounded, t('withdrawalStats'), () => _soon(t('withdrawalStats'))),
            _action(Icons.wallet_rounded, t('wallet'), () => _open(const WalletScreen())),
            _action(Icons.receipt_long_rounded, t('transactions'), () => _open(const TransactionsScreen())),
          ]),
          const SizedBox(height: 8), TextButton.icon(onPressed: () => _open(const TransactionsScreen()), icon: const Icon(Icons.receipt_long_rounded), label: Text(t('allTransactions')), style: TextButton.styleFrom(foregroundColor: const Color(0xFF9B6500))),
        ]),
      )),
    );
  }

  Widget _header() => Row(children: [
    ClipOval(child: Image.asset('assets/azad_coin_logo.png', width: 45, height: 45, fit: BoxFit.cover)),
    const SizedBox(width: 10), const Text('AZAD', style: TextStyle(color: Color(0xFFE4A105), fontSize: 25, fontWeight: FontWeight.w900)), const Spacer(),
    _icon(AzadCoinApp.of(context).themeMode == ThemeMode.dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined, AzadCoinApp.of(context).toggleTheme),
    const SizedBox(width: 7), _languageButton(), const SizedBox(width: 7), _icon(Icons.notifications_none_rounded, () => _soon('Notifications')),
  ]);

  Widget _icon(IconData icon, VoidCallback tap) => Material(
    color: Theme.of(context).colorScheme.surface,
    borderRadius: BorderRadius.circular(14),
    child: InkWell(onTap: tap, borderRadius: BorderRadius.circular(14), child: Container(width: 42, height: 42, alignment: Alignment.center, child: Icon(icon, color: const Color(0xFF292929)))),
  );

  Widget _languageButton() => PopupMenuButton<Locale>(
    tooltip: AppStrings.of(context, 'language'),
    onSelected: AzadCoinApp.of(context).setLocale,
    itemBuilder: (_) => const [
      PopupMenuItem(value: Locale('en'), child: Text('English')),
      PopupMenuItem(value: Locale('ps'), child: Text('پښتو')),
      PopupMenuItem(value: Locale('fa'), child: Text('دری')),
    ],
    child: Container(width: 54, height: 42, alignment: Alignment.center, decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(14)), child: Icon(Icons.language_rounded, color: Theme.of(context).colorScheme.onSurface)),
  );

  Widget _goldCard(double total, double usdt, double azad, NumberFormat money) => Container(
    height: 365, padding: const EdgeInsets.all(23), decoration: BoxDecoration(borderRadius: BorderRadius.circular(32), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF281600), Color(0xFF765017), Color(0xFF170C03)]), border: Border.all(color: const Color(0xFFDBAF4B)), boxShadow: const [BoxShadow(color: Color(0x332A1700), blurRadius: 22, offset: Offset(0, 10))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [ClipOval(child: Image.asset('assets/azad_coin_logo.png', width: 52, height: 52, fit: BoxFit.cover)), const SizedBox(width: 12), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('A Z A D', style: TextStyle(color: Color(0xFFFFD978), fontSize: 20, letterSpacing: 4, fontWeight: FontWeight.w900)), Text('GOLD PREMIUM', style: TextStyle(color: Color(0xFFF0D094), fontSize: 11, letterSpacing: 3, fontWeight: FontWeight.w700))]), const Spacer(), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF276D4C), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF66C695))), child: const Text('ACTIVE', style: TextStyle(color: Color(0xFFABF3C9), fontWeight: FontWeight.w800))) ]),
      const Spacer(), Text(AppStrings.of(context, 'totalBalance').toUpperCase(), style: const TextStyle(color: Color(0xFFE2BF7E), fontSize: 12, letterSpacing: 3)), const SizedBox(height: 3), Text(loading ? '—' : money.format(total), style: const TextStyle(color: Color(0xFFFFDA7A), fontSize: 34, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text('${money.format(usdt)} USDT  •  ${NumberFormat('#,##0.######').format(azad)} AZAD', style: const TextStyle(color: Color(0xFFF1D39A), fontWeight: FontWeight.w600)),
      const Spacer(), Row(children: [Container(width: 58, height: 44, decoration: BoxDecoration(color: const Color(0xFFD9AD3E), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.memory_rounded, color: Color(0xFF875707), size: 31)), const SizedBox(width: 15), const Text('••••  ••••  ••••  4567', style: TextStyle(color: Color(0xFFFFE1A4), letterSpacing: 2, fontSize: 15, fontWeight: FontWeight.w800))]), const SizedBox(height: 18),
      const Row(children: [Expanded(child: _Label('CARD HOLDER', 'AZAD MEMBER')), _Label('EXPIRES', '07/36'), SizedBox(width: 24), _Label('CVC', '•••')]),
    ]),
  );

  Widget _price() => Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 17), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFF0DFB2))), child: Row(children: [Container(width: 10, height: 10, decoration: const BoxDecoration(color: Color(0xFF35D6A6), shape: BoxShape.circle)), const SizedBox(width: 12), Text(AppStrings.of(context, 'price').toUpperCase(), style: const TextStyle(color: Color(0xFF857B69), fontWeight: FontWeight.w800, letterSpacing: 1.4)), const Spacer(), Text('\$${azadPrice.toStringAsFixed(6)}', style: const TextStyle(color: Color(0xFF9B6500), fontSize: 17, fontWeight: FontWeight.w900))]));

  Widget _action(IconData icon, String label, VoidCallback tap) => Material(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(24), child: InkWell(onTap: tap, borderRadius: BorderRadius.circular(24), child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFF0DFB2))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Container(width: 58, height: 58, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFFFFF7E5), border: Border.all(color: const Color(0xFFF2D487))), child: Icon(icon, color: const Color(0xFFE9A300), size: 30)), const SizedBox(height: 12), Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: Theme.of(context).colorScheme.onSurface, fontWeight: FontWeight.w800))]))));
}

class _Label extends StatelessWidget {
  final String label, value;
  const _Label(this.label, this.value);
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Color(0xFFE1BE7C), fontSize: 9, letterSpacing: 1.4)), const SizedBox(height: 4), Text(value, style: const TextStyle(color: Color(0xFFFFE1A4), fontSize: 13, fontWeight: FontWeight.w800))]);
}
