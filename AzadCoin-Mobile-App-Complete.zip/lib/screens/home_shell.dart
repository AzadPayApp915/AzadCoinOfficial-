import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../app_strings.dart';
import 'dashboard_screen.dart';
import 'wallet_screen.dart';
import 'services_screen.dart';
import 'profile_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final pages = const [DashboardScreen(), WalletScreen(), ServicesScreen(), ProfileScreen()];

  @override
  Widget build(BuildContext context) {
    String t(String key) => AppStrings.of(context, key);
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        backgroundColor: AppColors.surface,
        indicatorColor: AppColors.gold.withOpacity(0.2),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_rounded), label: t('dashboard')),
          NavigationDestination(icon: const Icon(Icons.account_balance_wallet_rounded), label: t('wallet')),
          NavigationDestination(icon: const Icon(Icons.headset_mic_outlined), label: t('support')),
          NavigationDestination(icon: const Icon(Icons.person_rounded), label: t('profile')),
        ],
      ),
    );
  }
}
