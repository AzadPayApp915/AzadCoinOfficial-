import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'dashboard_screen.dart';
import 'wallet_screen.dart';
import 'swap_screen.dart';
import 'services_screen.dart';
import 'profile_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final pages = const [DashboardScreen(), WalletScreen(), SwapScreen(), ServicesScreen(), ProfileScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        backgroundColor: AppColors.surface,
        indicatorColor: AppColors.gold.withOpacity(0.2),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'کور'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_rounded), label: 'والټ'),
          NavigationDestination(icon: Icon(Icons.swap_horiz_rounded), label: 'سواپ'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'خدمات'),
          NavigationDestination(icon: Icon(Icons.person_rounded), label: 'پروفایل'),
        ],
      ),
    );
  }
}
