import 'package:flutter/material.dart';
import '../app_strings.dart';
import 'dashboard_screen.dart';
import 'wallet_screen.dart';
import 'services_screen.dart';
import 'profile_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final pages = const [DashboardScreen(), WalletScreen(), ServicesScreen(), ProfileScreen()];

  @override
  Widget build(BuildContext context) {
    String t(String key) => AppStrings.of(context, key);
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          height: 76,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            border: Border(top: BorderSide(color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF2A2E39) : const Color(0xFFF0E7D2))),
          ),
          child: Row(children: [
            _item(0, Icons.home_rounded, t('dashboard')),
            _item(1, Icons.account_balance_wallet_rounded, t('wallet')),
            _item(2, Icons.headset_mic_outlined, t('support')),
            _item(3, Icons.person_rounded, t('profile')),
          ]),
        ),
      ),
    );
  }

  Widget _item(int itemIndex, IconData icon, String label) {
    final selected = index == itemIndex;
    return Expanded(child: InkWell(
      onTap: () => setState(() => index = itemIndex),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AnimatedContainer(duration: const Duration(milliseconds: 180), width: selected ? 66 : 42, height: 36,
          decoration: BoxDecoration(color: selected ? const Color(0xFFFFE5A6) : Colors.transparent, borderRadius: BorderRadius.circular(20)),
          child: Icon(icon, color: selected ? const Color(0xFFB77700) : Theme.of(context).colorScheme.onSurface.withOpacity(.55))),
        const SizedBox(height: 3), Text(label, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: selected ? const Color(0xFFB77700) : Theme.of(context).colorScheme.onSurface.withOpacity(.55), fontWeight: selected ? FontWeight.w800 : FontWeight.w600)),
      ]),
    ));
  }
}
