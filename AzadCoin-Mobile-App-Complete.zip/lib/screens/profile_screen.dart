import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';
import 'auth_screen.dart';
import 'transactions_screen.dart';
import 'staking_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = SupabaseService.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        GlassCard(child: Column(children: [
          const CircleAvatar(radius: 36, backgroundColor: AppColors.gold,
              child: Icon(Icons.person, size: 40, color: Colors.black)),
          const SizedBox(height: 12),
          Text(user?.email ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          const Text('Azad Coin Member', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ])),
        const SizedBox(height: 16),
        ListTile(leading: const Icon(Icons.savings_outlined, color: AppColors.gold), title: const Text('Islamic Staking'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StakingScreen()))),
        ListTile(leading: const Icon(Icons.receipt_long_outlined, color: AppColors.gold), title: const Text('Transactions'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionsScreen()))),
        const ListTile(leading: Icon(Icons.fingerprint, color: AppColors.gold), title: Text('Biometric Security'), subtitle: Text('Device-protected login')),
        const ListTile(leading: Icon(Icons.language, color: AppColors.gold), title: Text('English · پښتو · دری')),
        const SizedBox(height: 12),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.red),
          onPressed: () async {
            await SupabaseService.signOut();
            if (context.mounted) {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const AuthScreen()), (_) => false);
            }
          },
          child: const Text('وتل / Logout', style: TextStyle(color: Colors.white)),
        ),
      ]),
    );
  }
}
