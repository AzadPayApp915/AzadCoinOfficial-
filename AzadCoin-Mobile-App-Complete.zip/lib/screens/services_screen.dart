import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});
  @override Widget build(BuildContext context) {
    const items = [
      (Icons.verified_user_outlined, 'KYC Verification'), (Icons.groups_outlined, 'Referral'),
      (Icons.bolt_outlined, 'Mining'), (Icons.confirmation_number_outlined, 'Lottery'),
      (Icons.credit_card_outlined, 'AZAD Card'), (Icons.card_giftcard_outlined, 'Gift Code'),
      (Icons.support_agent_outlined, 'Support & AI'), (Icons.notifications_none, 'Notifications'),
    ];
    return Scaffold(appBar: AppBar(title: const Text('Services')), body: GridView.builder(
      padding: const EdgeInsets.all(16), itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.2),
      itemBuilder: (_, i) => InkWell(borderRadius: BorderRadius.circular(24), onTap: () => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${items[i].$2} uses the existing Azad Coin backend.'))), child: GlassCard(
          padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(items[i].$1, color: AppColors.gold, size: 34), const SizedBox(height: 10),
            Text(items[i].$2, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
          ]))),
    ));
  }
}
