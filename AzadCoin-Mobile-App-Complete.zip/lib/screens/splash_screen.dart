import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';
import 'auth_screen.dart';
import 'home_shell.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1200), () async {
      if (!mounted) return;
      try {
        if (await SupabaseService.isMaintenanceEnabled()) {
          if (!mounted) return;
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const _MaintenanceScreen()));
          return;
        }
      } catch (_) {}
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => SupabaseService.isLoggedIn ? const HomeShell() : const AuthScreen(),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 96, height: 96,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(colors: [AppColors.gold, Color(0xFFB8860B)]),
            ),
            child: const Center(child: Text('A', style: TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: Colors.black))),
          ),
          const SizedBox(height: 20),
          const Text('Azad Coin', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('آزاد کوین', style: TextStyle(fontSize: 16, color: AppColors.textSecondary)),
        ]),
      ),
    );
  }
}

class _MaintenanceScreen extends StatelessWidget {
  const _MaintenanceScreen();
  @override Widget build(BuildContext context) => const Scaffold(body: SafeArea(child: Center(child: Padding(
    padding: EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.engineering_rounded, size: 72, color: AppColors.gold), SizedBox(height: 20),
      Text('Azad Coin is under maintenance', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      SizedBox(height: 10), Text('مهرباني وکړئ وروسته بیا هڅه وکړئ', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary)),
    ]),
  ))));
}
