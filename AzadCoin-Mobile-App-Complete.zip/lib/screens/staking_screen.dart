import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class StakingScreen extends StatelessWidget {
  const StakingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final numFmt = NumberFormat('#,##0.######');
    return Scaffold(
      appBar: AppBar(title: const Text('اسلامي سټیکینګ')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: SupabaseService.getStakingPositions(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final positions = snap.data!;
          if (positions.isEmpty) {
            return const Center(child: Text('هیڅ فعاله سټیکینګ پوزیشن نشته', style: TextStyle(color: AppColors.textSecondary)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: positions.length,
            itemBuilder: (_, i) {
              final p = positions[i];
              final amount = (p['amount'] as num?)?.toDouble() ?? 0;
              final earned = (p['total_profit_earned'] as num?)?.toDouble() ?? 0;
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p['plan_name'] ?? 'Yearly Plan', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const SizedBox(height: 10),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('اصلي مقدار', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                    Text('${numFmt.format(amount)} AZAD', style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                  const SizedBox(height: 6),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('ګټه', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                    Text('+${numFmt.format(earned)} AZAD', style: const TextStyle(color: AppColors.green, fontWeight: FontWeight.w800)),
                  ]),
                ])),
              );
            },
          );
        },
      ),
    );
  }
}
