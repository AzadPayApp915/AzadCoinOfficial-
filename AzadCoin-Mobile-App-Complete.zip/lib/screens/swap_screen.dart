import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class SwapScreen extends StatefulWidget {
  const SwapScreen({super.key});
  @override State<SwapScreen> createState() => _SwapScreenState();
}
class _SwapScreenState extends State<SwapScreen> {
  final amount = TextEditingController(); bool buy = true; bool loading = false;
  Future<void> _submit() async {
    final parsed = double.tryParse(amount.text); if (parsed == null || parsed <= 0) return;
    setState(() => loading = true);
    try {
      await SupabaseService.executeSwap(side: buy ? 'buy' : 'sell', fromAsset: buy ? 'USDT' : 'AZAD',
        toAsset: buy ? 'AZAD' : 'USDT', amount: amount.text.trim());
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('Swap completed by the server.')));
      amount.clear();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: AppColors.red, content: Text(e.toString())));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Swap AZAD')),
    body: ListView(padding: const EdgeInsets.all(16), children: [GlassCard(child: Column(children: [
      SegmentedButton<bool>(segments: const [
        ButtonSegment(value: true, label: Text('Buy AZAD')), ButtonSegment(value: false, label: Text('Sell AZAD')),
      ], selected: {buy}, onSelectionChanged: (v) => setState(() => buy = v.first)), const SizedBox(height: 24),
      TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: 'Amount in ${buy ? 'USDT' : 'AZAD'}', suffixText: buy ? 'USDT' : 'AZAD')),
      const SizedBox(height: 12), const Text('Final price and fees are calculated by the secure server.',
        style: TextStyle(color: AppColors.textSecondary, fontSize: 12)), const SizedBox(height: 20),
      ElevatedButton(onPressed: loading ? null : _submit,
        child: loading ? const CircularProgressIndicator() : Text(buy ? 'Buy AZAD' : 'Sell AZAD')),
    ]))]));
}
