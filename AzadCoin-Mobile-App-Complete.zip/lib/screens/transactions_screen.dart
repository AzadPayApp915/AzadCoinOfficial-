import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';

class TransactionsScreen extends StatelessWidget {
  const TransactionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final numFmt = NumberFormat('#,##0.######');
    return Scaffold(
      appBar: AppBar(title: const Text('معاملې')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: SupabaseService.getTransactions(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final txs = snap.data!;
          if (txs.isEmpty) {
            return const Center(child: Text('هیڅ معامله نشته', style: TextStyle(color: AppColors.textSecondary)));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: txs.length,
            separatorBuilder: (_, __) => const Divider(height: 1, color: Colors.white10),
            itemBuilder: (_, i) {
              final t = txs[i];
              final amount = (t['amount'] as num?)?.toDouble() ?? 0;
              final type = (t['type'] ?? '').toString();
              final isCredit = type.contains('deposit') || type.contains('reward') || type.contains('buy') || type.contains('commission');
              final date = DateTime.tryParse((t['created_at'] ?? '').toString());
              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(
                  backgroundColor: (isCredit ? AppColors.green : AppColors.red).withOpacity(0.15),
                  child: Icon(isCredit ? Icons.south_west : Icons.north_east,
                      color: isCredit ? AppColors.green : AppColors.red, size: 18),
                ),
                title: Text(type.replaceAll('_', ' '), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                subtitle: date == null ? null : Text(DateFormat.yMMMd().add_Hm().format(date),
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                trailing: Text('${isCredit ? '+' : '-'}${numFmt.format(amount)}',
                    style: TextStyle(fontWeight: FontWeight.w800, color: isCredit ? AppColors.green : AppColors.red)),
              );
            },
          );
        },
      ),
    );
  }
}
