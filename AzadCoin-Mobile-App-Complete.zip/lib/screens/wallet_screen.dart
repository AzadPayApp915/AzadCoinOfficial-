import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  Map<String, dynamic>? wallet;
  String? depositAddress;
  String depositAsset = 'USDT';
  bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final data = await SupabaseService.getWallet();
    if (mounted) setState(() { wallet = data; loading = false; });
  }
  String _amount(String key) => ((wallet?[key] as num?) ?? 0).toStringAsFixed(6);
  void _message(String text, {bool error = false}) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: error ? AppColors.red : AppColors.green, content: Text(text)));
  }
  Future<void> _deposit(String asset) async {
    try {
      final result = await SupabaseService.generateDepositAddress(asset);
      final address = result is Map ? (result['address'] ?? result['deposit_address'] ?? '').toString() : result.toString();
      if (!mounted) return;
      setState(() { depositAsset = asset; depositAddress = address; });
    } catch (e) { _message(e.toString(), error: true); }
  }
  void _sendSheet() {
    final recipient = TextEditingController(); final amount = TextEditingController(); String asset = 'AZAD';
    showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(builder: (_, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(24, 8, 24, MediaQuery.of(sheetContext).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFFFE9B6), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.send_rounded, color: Color(0xFFE69A00))), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Send AZAD', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), Text('Transfer to another Azad Coin user', style: TextStyle(color: AppColors.textSecondary, fontSize: 12))]))]), const SizedBox(height: 18),
          DropdownButtonFormField<String>(value: asset, items: const [
            DropdownMenuItem(value: 'AZAD', child: Text('AZAD')), DropdownMenuItem(value: 'USDT', child: Text('USDT')),
          ], onChanged: (v) => setSheet(() => asset = v ?? 'AZAD')), const SizedBox(height: 12),
          TextField(controller: recipient, decoration: const InputDecoration(labelText: 'Recipient Email / Referral Code', prefixIcon: Icon(Icons.mail_outline_rounded))), const SizedBox(height: 12),
          TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: 'Amount ($asset)', prefixIcon: const Icon(Icons.monetization_on_outlined), suffixText: 'MAX')), const SizedBox(height: 18),
          ElevatedButton(onPressed: () async {
            try {
              if (asset == 'AZAD') { final value = double.tryParse(amount.text) ?? 0; if (value < 500 || value > 100000) throw Exception('AZAD amount must be 500–100,000.'); }
              await SupabaseService.transfer(recipient: recipient.text.trim(), asset: asset, amount: amount.text.trim());
              if (sheetContext.mounted) Navigator.pop(sheetContext); _message('Transfer submitted successfully.'); _load();
            } catch (e) { _message(e.toString(), error: true); }
          }, child: const Text('Continue')),
        ]))));
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Wallet'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))]),
    body: RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(16), children: [
      const Row(children: [Icon(Icons.download_rounded, color: AppColors.green), SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('My Wallet', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), Text('Your unique deposit addresses', style: TextStyle(color: AppColors.textSecondary, fontSize: 12))])]),
      const SizedBox(height: 16),
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFF0FFF7), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF9DE2BE))), child: const Row(children: [Icon(Icons.bolt_rounded, color: AppColors.green), SizedBox(width: 10), Expanded(child: Text('Automatic Deposit Detection', style: TextStyle(fontWeight: FontWeight.w800))), Icon(Icons.chevron_right)])),
      const SizedBox(height: 16),
      _assetCard('USDT', 'Tether USD', _amount('usdt_balance'), AppColors.green), const SizedBox(height: 10),
      _assetCard('AZAD', 'Azad Coin', _amount('azad_balance'), AppColors.gold), const SizedBox(height: 16),
      if (depositAddress != null) _depositCard(),
      Row(children: [Expanded(child: ElevatedButton.icon(onPressed: () => _deposit('USDT'), icon: const Icon(Icons.qr_code_rounded), label: const Text('Generate Deposit'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: _sendSheet, icon: const Icon(Icons.send_rounded), label: const Text('Send AZAD'), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52))))]),
      const SizedBox(height: 12), const Text('Deposits are credited only after secure server and network verification.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
    ])),
  );

  Widget _assetCard(String asset, String subtitle, String balance, Color color) => Container(
    padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: color.withOpacity(.35))),
    child: Row(children: [CircleAvatar(backgroundColor: color.withOpacity(.16), child: Text(asset == 'USDT' ? '₮' : 'A', style: TextStyle(color: color, fontWeight: FontWeight.w900))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(asset, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), Text(subtitle, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12))])), Text(balance, style: TextStyle(color: color, fontSize: 17, fontWeight: FontWeight.w900))]),
  );

  Widget _depositCard() => Container(
    margin: const EdgeInsets.only(bottom: 16), padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFA7E4C5))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Icon(Icons.qr_code_2_rounded, color: AppColors.green), const SizedBox(width: 8), Text('$depositAsset Deposit Address', style: const TextStyle(fontWeight: FontWeight.w900)), const Spacer(), const Text('BEP20', style: TextStyle(color: AppColors.textSecondary, fontSize: 12))]), const SizedBox(height: 16), Center(child: QrImageView(data: depositAddress!, size: 156, eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: Colors.black), dataModuleStyle: const QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: Colors.black))), const SizedBox(height: 14), Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: const Color(0xFFF8F8F8), borderRadius: BorderRadius.circular(12)), child: SelectableText(depositAddress!, style: const TextStyle(fontSize: 12))), const SizedBox(height: 10), SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: depositAddress!)); _message('Address copied'); }, icon: const Icon(Icons.copy_rounded), label: const Text('Copy Address')))]),
  );
  Widget _balance(String asset, String value, Color color) => Row(children: [
    CircleAvatar(backgroundColor: color.withOpacity(.15), child: Text(asset[0], style: TextStyle(color: color, fontWeight: FontWeight.w900))),
    const SizedBox(width: 12), Text(asset, style: const TextStyle(fontWeight: FontWeight.w700)), const Spacer(),
    Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 17)),
  ]);
}
