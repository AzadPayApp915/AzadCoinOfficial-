import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/supabase_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  Map<String, dynamic>? wallet;
  bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final data = await SupabaseService.getWallet();
    if (mounted) setState(() { wallet = data; loading = false; });
  }
  String _amount(String key) => ((wallet?[key] as num?) ?? 0).toStringAsFixed(6);
  void _message(String text, {bool error = false}) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: error ? AppColors.red : AppColors.green, content: Text(text)));
  }
  Future<void> _deposit(String asset) async {
    try {
      final result = await SupabaseService.generateDepositAddress(asset);
      final address = result is Map ? (result['address'] ?? result['deposit_address'] ?? '').toString() : result.toString();
      if (!mounted) return;
      showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => Padding(
        padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('$asset BEP20 Deposit', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16), SelectableText(address, textAlign: TextAlign.center), const SizedBox(height: 16),
          ElevatedButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: address)); Navigator.pop(context); },
            icon: const Icon(Icons.copy), label: const Text('Copy Address')),
        ])));
    } catch (e) { _message(e.toString(), error: true); }
  }
  void _sendSheet() {
    final recipient = TextEditingController(); final amount = TextEditingController(); String asset = 'AZAD';
    showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(builder: (_, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(24, 8, 24, MediaQuery.of(sheetContext).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Send', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)), const SizedBox(height: 14),
          DropdownButtonFormField<String>(value: asset, items: const [
            DropdownMenuItem(value: 'AZAD', child: Text('AZAD')), DropdownMenuItem(value: 'USDT', child: Text('USDT')),
          ], onChanged: (v) => setSheet(() => asset = v ?? 'AZAD')), const SizedBox(height: 12),
          TextField(controller: recipient, decoration: const InputDecoration(labelText: 'Email or wallet address')), const SizedBox(height: 12),
          TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Amount (6 decimals)')), const SizedBox(height: 18),
          ElevatedButton(onPressed: () async {
            try {
              if (asset == 'AZAD') { final value = double.tryParse(amount.text) ?? 0; if (value < 500 || value > 100000) throw Exception('AZAD amount must be 500–100,000.'); }
              await SupabaseService.transfer(recipient: recipient.text.trim(), asset: asset, amount: amount.text.trim());
              if (sheetContext.mounted) Navigator.pop(sheetContext); _message('Transfer submitted successfully.'); _load();
            } catch (e) { _message(e.toString(), error: true); }
          }, child: const Text('Confirm Send')),
        ]))));
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Wallet')),
    body: RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(16), children: [
      GlassCard(child: loading ? const Center(child: CircularProgressIndicator()) : Column(children: [
        _balance('AZAD', _amount('azad_balance'), AppColors.gold), const Divider(height: 28),
        _balance('USDT', _amount('usdt_balance'), AppColors.green), const Divider(height: 28),
        _balance('AFN', _amount('afn_balance'), Colors.lightBlueAccent),
      ])), const SizedBox(height: 18),
      Row(children: [Expanded(child: ElevatedButton.icon(onPressed: () => _deposit('AZAD'), icon: const Icon(Icons.south_west), label: const Text('Deposit'))),
        const SizedBox(width: 10), Expanded(child: ElevatedButton.icon(onPressed: _sendSheet, icon: const Icon(Icons.north_east), label: const Text('Send')))]),
      const SizedBox(height: 12), const Text('BEP20 deposits are credited only after server verification.',
        textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
    ])));
  Widget _balance(String asset, String value, Color color) => Row(children: [
    CircleAvatar(backgroundColor: color.withOpacity(.15), child: Text(asset[0], style: TextStyle(color: color, fontWeight: FontWeight.w900))),
    const SizedBox(width: 12), Text(asset, style: const TextStyle(fontWeight: FontWeight.w700)), const Spacer(),
    Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 17)),
  ]);
}
