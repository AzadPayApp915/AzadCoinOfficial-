import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;
  static User? get currentUser => client.auth.currentUser;
  static bool get isLoggedIn => currentUser != null;

  static Future<AuthResponse> signIn(String email, String password) =>
      client.auth.signInWithPassword(email: email, password: password);

  static Future<AuthResponse> signUp(String email, String password) =>
      client.auth.signUp(email: email, password: password);

  static Future<void> sendSignupOtp(String email) async {
    await client.functions.invoke('send-otp', body: {'email': email});
  }

  static Future<dynamic> verifySignupOtp(String email, String otp) async {
    final response = await client.functions.invoke(
      'verify-otp', body: {'email': email, 'otp': otp});
    if (response.status >= 400) throw Exception(response.data.toString());
    return response.data;
  }

  static Future<void> signOut() => client.auth.signOut();

  /// Wallet balances (AZAD / USDT / AFN) from profiles + wallets tables
  static Future<Map<String, dynamic>?> getWallet() async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    final rows = await client.from('wallets').select().eq('user_id', uid);
    return rows.isNotEmpty ? rows.first : null;
  }

  static Future<Map<String, dynamic>?> getProfile() async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    final rows = await client.from('profiles').select().eq('user_id', uid).limit(1);
    return rows.isNotEmpty ? rows.first : null;
  }

  static Future<bool> isMaintenanceEnabled() async {
    final rows = await client.from('maintenance_settings').select().limit(1);
    if (rows.isEmpty) return false;
    return rows.first['is_enabled'] == true || rows.first['enabled'] == true;
  }

  static Future<void> assertAccountAllowed({String? action}) async {
    final profile = await getProfile();
    if (profile == null) return;
    if (profile['is_banned'] == true || profile['is_blocked'] == true) {
      throw Exception('Your account is blocked. Please contact support.');
    }
    if (action == 'send' && profile['send_blocked'] == true) {
      throw Exception('Sending is disabled for this account.');
    }
    if (action == 'withdraw' && profile['withdraw_blocked'] == true) {
      throw Exception('Withdrawals are disabled for this account.');
    }
  }

  static Future<double> getAzadPrice() async {
    final rows = await client.from('token_settings').select('current_price_usdt').limit(1);
    if (rows.isEmpty) return 0;
    return (rows.first['current_price_usdt'] as num?)?.toDouble() ?? 0;
  }

  static Future<List<Map<String, dynamic>>> getStakingPositions() async {
    final uid = currentUser?.id;
    if (uid == null) return [];
    return List<Map<String, dynamic>>.from(
      await client.from('islamic_staking_positions').select()
          .eq('user_id', uid).order('created_at', ascending: false),
    );
  }

  static Future<List<Map<String, dynamic>>> getTransactions({int limit = 50}) async {
    final uid = currentUser?.id;
    if (uid == null) return [];
    return List<Map<String, dynamic>>.from(
      await client.from('transactions').select()
          .eq('user_id', uid).order('created_at', ascending: false).limit(limit),
    );
  }

  static Future<List<Map<String, dynamic>>> getStakingPools() async =>
      List<Map<String, dynamic>>.from(await client
          .from('islamic_staking_pools').select().eq('is_active', true));

  static Future<dynamic> executeSwap({
    required String side,
    required String fromAsset,
    required String toAsset,
    required String amount,
  }) => client.rpc('execute_swap', params: {
        'p_side': side, 'p_from_asset': fromAsset,
        'p_to_asset': toAsset, 'p_amount': amount,
      });

  static Future<dynamic> transfer({
    required String recipient,
    required String asset,
    required String amount,
  }) async {
    await assertAccountAllowed(action: 'send');
    return client.rpc('transfer_to_user', params: {
      'p_recipient': recipient, 'p_asset': asset, 'p_amount': amount,
    });
  }

  static Future<dynamic> generateDepositAddress(String asset) async {
    final response = await client.functions.invoke(
      'wallet-generate-address', body: {'asset': asset, 'network': 'BEP20'});
    if (response.status >= 400) throw Exception(response.data.toString());
    return response.data;
  }

  static Future<dynamic> sendOnChain({
    required String address,
    required String asset,
    required String amount,
  }) async {
    await assertAccountAllowed(action: 'withdraw');
    final response = await client.functions.invoke('wallet-send-onchain', body: {
      'address': address, 'asset': asset, 'network': 'BEP20', 'amount': amount,
    });
    if (response.status >= 400) throw Exception(response.data.toString());
    return response.data;
  }

  static Future<dynamic> claimDailyReward() => client.rpc('claim_daily_reward');

  static RealtimeChannel subscribeToWallet(void Function() refresh) {
    final uid = currentUser?.id ?? '';
    return client.channel('wallet-$uid').onPostgresChanges(
      event: PostgresChangeEvent.update, schema: 'public', table: 'wallets',
      filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq,
        column: 'user_id', value: uid), callback: (_) => refresh(),
    ).subscribe();
  }
}
